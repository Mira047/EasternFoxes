/*
 * Copyright (c) 2019 OpenFTC Team
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.firstinspires.ftc.teamcode.sezon2022;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfInt;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.imgproc.Moments;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvPipeline;
import org.openftc.easyopencv.OpenCvWebcam;

import java.util.ArrayList;
import java.util.List;

@Config
public class FreightDetectRecognition
{
    public  OpenCvWebcam webcam;
    Point topLeft,topRight,topMid,bottomLeft,bottomMid,bottomRight;
    static int rezX=320;
    static int rezY=240;
    static  int lower1 = 0;
    static  int lower2 = 113;
    static  int lower3 = 219;
    static  int upper1 = 32;
    static  int upper2 = 255;
    static  int upper3 = 255;
    public static double tresh = 1.0/500.0 * ((double)rezX*(double) rezY);

    HardwareMap hardwareMap;
    Telemetry telemetry;

    public FreightDetectRecognition(HardwareMap map, Telemetry tel){
        hardwareMap = map;
        telemetry = tel;
    }

    public void start(){
        webcam.setPipeline(new SamplePipeline());
        webcam.startStreaming(rezX, rezY, OpenCvCameraRotation.UPRIGHT);
    }

    public void initCamera(){
        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        webcam = OpenCvCameraFactory.getInstance().createWebcam(hardwareMap.get(WebcamName.class, "Webcam 1"), cameraMonitorViewId);
        webcam.setPipeline(new SamplePipeline());
        webcam.setMillisecondsPermissionTimeout(2500);
        webcam.openCameraDevice();
    }

    void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {

        }
    }

    public  void stop(){
        webcam.stopStreaming();
        webcam.stopRecordingPipeline();
    }

    class SamplePipeline extends OpenCvPipeline
    {
        boolean viewportPaused;
        public Mat Channel = new Mat();
        public Mat Channel2 = new Mat();
        public Mat drawing = new Mat();
        Mat hierarchy = new Mat();
        MatOfPoint hl = new MatOfPoint();
        Mat element = Imgproc.getStructuringElement(Imgproc.MORPH_RECT,
                new Size(3, 3));

        @Override
        public Mat processFrame(Mat input)
        {
            imageProc(input);
            return drawing;
        }

        public MatOfPoint convertIndexesToPoints(MatOfPoint contour, MatOfInt indexes) {
            int[] arrIndex = indexes.toArray();
            Point[] arrContour = contour.toArray();
            Point[] arrPoints = new Point[arrIndex.length];

            for (int i=0;i<arrIndex.length;i++) {
                arrPoints[i] = arrContour[arrIndex[i]];
            }

            MatOfPoint hull = new MatOfPoint();
            hull.fromArray(arrPoints);
            return hull;
        }

        void Sleep(int ms){
            try {
                Thread.sleep(ms);
            }catch (Exception ex){

            }
        }

        void imageProc(Mat frame) {
            Imgproc.cvtColor(frame,Channel,Imgproc.COLOR_RGB2HLS);
            Core.inRange(Channel,new Scalar(lower1,lower2,lower3),new Scalar(upper1,upper2,upper3),Channel2);
            Imgproc.dilate(Channel2,Channel,element);
            Imgproc.Canny(Channel,Channel2,100,200,5);
            List<MatOfPoint> contours = new ArrayList<>();
            Imgproc.findContours(Channel2,contours,hierarchy,Imgproc.RETR_TREE,Imgproc.CHAIN_APPROX_SIMPLE);
            List<MatOfInt> hull = new ArrayList<>();
            for(int i=0; i < contours.size(); i++){
                hull.add(new MatOfInt());
            }
            drawing = Mat.zeros(Channel2.size(), CvType.CV_8UC3);

            for(int i=0; i<contours.size(); i++){
                Imgproc.convexHull(contours.get(i), hull.get(i));

            }

            List<Point[]> hullpoints = new ArrayList<Point[]>();
            for(int i=0; i < hull.size(); i++){
                Point[] points = new Point[hull.get(i).rows()];
                for(int j=0; j < hull.get(i).rows(); j++){
                    int index = (int)hull.get(i).get(j, 0)[0];
                    points[j] = new Point(contours.get(i).get(index, 0)[0], contours.get(i).get(index, 0)[1]);
                }

                hullpoints.add(points);
            }
            List<MatOfPoint> hullmop = new ArrayList<MatOfPoint>();
            for(int i=0; i < hullpoints.size(); i++){
                MatOfPoint mop = new MatOfPoint();
                mop.fromArray(hullpoints.get(i));
                hullmop.add(mop);
            }


            Scalar color = new Scalar(0, 255, 0);
            for (int i = 0; i < hull.size(); i++) {
                double arr = Imgproc.contourArea(hullmop.get(i));
                if (tresh <= arr) {
                    Moments mom = Imgproc.moments(hullmop.get(i));
                    int cx = (int)(mom.m10 / mom.m00);
                    int cy = (int)(mom.m01 / mom.m00);
                    Imgproc.drawMarker(drawing, new Point(cx, cy), new Scalar(255, 0, 0));
                    Imgproc.drawContours(drawing, hullmop, (int)i, color, 2, Imgproc.LINE_8, hierarchy, 0);
                }
                //Imgproc.drawContours(drawing, contours, i, color, 2, Imgproc.LINE_8, hierarchy, 0, new Point());
            }

        }

        @Override
        public void onViewportTapped()
        {
            viewportPaused = !viewportPaused;

            if(viewportPaused)
            {
                webcam.pauseViewport();
            }
            else
            {
                webcam.resumeViewport();
            }
        }
    }
}

