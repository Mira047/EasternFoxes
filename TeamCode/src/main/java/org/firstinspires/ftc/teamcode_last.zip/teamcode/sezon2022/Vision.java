package org.firstinspires.ftc.teamcode.sezon2022;

public class Vision {
}
