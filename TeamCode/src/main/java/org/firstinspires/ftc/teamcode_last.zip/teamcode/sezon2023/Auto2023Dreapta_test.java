package org.firstinspires.ftc.teamcode.sezon2023;

import android.graphics.Camera;
import android.hardware.camera2.params.BlackLevelPattern;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.ColorSensor;

import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoController;

import org.apache.commons.math3.geometry.euclidean.twod.Line;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.sezon2022.CameraRecognition;
import org.firstinspires.ftc.teamcode.sezon2022.HardwareTesterInterpreter;
import org.firstinspires.ftc.teamcode.sezon2022.PipeLineDetector;
import org.opencv.core.Mat;

@Autonomous(name="Auto2023 Dreapta Test", group="Linear Opmode")
@Config
public class Auto2023Dreapta_test extends LinearOpMode {

    public String[] script = new String[]{
            "servo clawRotate 0.54",
            "servo clawLeft 0.55",
            "servo clawRight 0.44",
            "wait 200",
            "go posh 27 0 37",
            "motor lift 0 reset_position",
            "motor lift 1 power",
            "motor lift 760 position",
            "motor brat 0 reset_position",
            "motor brat 0.55 power",
            "motor brat -2250 position",
            "servo clawRotate 0.345",
            "wait 1500",
            "motor lift 400 position",
            "wait 400",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 600",
            "servo clawLeft 0.49",
            "servo clawRight 0.475",
            "servo clawRotate 0.55",
            "motor lift 0 position",
            "motor brat 0 position",
            "wait 1000",
            "go posh 54 -2 82",

            "motor lift 755 position",
            "servo clawRotate 0.522",
            "wait 500",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "go posh 51.4 -28.3 82",
            "wait 100",
            "servo clawLeft 0.555",
            "servo clawRight 0.42",
            "wait 300",
            "motor lift 1470 position",
            "wait 100",
            "servo clawRight 0.44",
            "wait 1000",
            "servo clawRotate 0.555",
            "wait 700",
            "motor lift 1490 position",
            "go posh 44 -18 80",

            "go posh 51.2 -2.9 40.5",
            "motor brat 0.6 power",
            "motor brat -2000 position",
            "servo clawRotate 0.37",

            "wait 2000",

            "motor lift 900 position",
            "wait 750",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 500",
            "servo clawLeft 0.55",
            "servo clawRight 0.44",
            "servo clawRotate 0.5",
            "motor brat 0 position",
            "motor lift 625 position",
            "servo clawRotate 0.521",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 500",
            "go posh 52 -28.2 80",
            "servo clawLeft 0.555",
            "servo clawRight 0.425",
            "wait 300",
            "motor lift 1500 position",
            "wait 100",
            "servo clawRight 0.44",
            "wait 1000",
            "servo clawRotate 0.555",
            "wait 700",
            "motor lift 1450 position",
            "go posh 44 -18 80",
            "go posh 51.4 -3.2 40.689",
            "motor brat 0.6 power",
            "motor brat -2000 position",
            "servo clawRotate 0.37",
            "wait 2000",

            "motor lift 900 position",
            "wait 800",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 200",
            "motor brat 0 position",
            "motor lift 0 position",
            "servo clawRotate 0.55",
            "servo clawLeft 0.55",
            "servo clawRight 0.44",
            "wait 500"


    };
    SampleMecanumDrive drive;
    CameraRecognition cameraRecognition;
    int caz;

    @Override
    public void runOpMode() throws InterruptedException {
        drive = new SampleMecanumDrive(hardwareMap);
        HardwareTesterInterpreter.initHWI(this,hardwareMap,telemetry,drive);

        cameraRecognition = new CameraRecognition(hardwareMap,telemetry,"red");
        cameraRecognition.initCamera();
        cameraRecognition.start(1);

        while(!opModeIsActive() && !isStopRequested()){
            if(cameraRecognition.detector.caz == PipeLineDetector.Status.VERDE1){
                caz = 1;
            }
            else if(cameraRecognition.detector.caz == PipeLineDetector.Status.ROSU2){
                caz = 2;
            } else if(cameraRecognition.detector.caz == PipeLineDetector.Status.ALBASTRU3){
                caz = 3;
            }
            telemetry.addData("detected", caz);
            telemetry.update();

        }

        waitForStart ();
        cameraRecognition.stop();
        telemetry.addData("Facem cazul",caz);

        while (opModeIsActive()) {
            main();
            break;
        }
    }



    void Wait(int ms){
        try{
            Thread.sleep(ms);
        }catch (Exception ex){

        }
    }


    private  void main(){
        for(int i=0;i<script.length;i++){
            if(isStopRequested())
            {
                break;
            }
            HardwareTesterInterpreter.interpretCommand(script[i]);
        }
        if(isStopRequested())
            return;
        if(caz == 1){
            HardwareTesterInterpreter.interpretCommand("go posh 49 26 80");
        } else if(caz == 2){
            HardwareTesterInterpreter.interpretCommand("go posh 49 0 0");
        } if(caz == 3){
            HardwareTesterInterpreter.interpretCommand("go posh 49 -28 0");
        }
    }
}
