package org.firstinspires.ftc.teamcode.drive.opmode;

import static java.lang.Math.PI;
import static java.lang.Math.atan2;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.sezon2022.Turret;

/**
 * This is a simple teleop routine for testing localization. Drive the robot around like a normal
 * teleop routine and make sure the robot's estimated pose matches the robot's actual pose (slight
 * errors are not out of the ordinary, especially with sudden drive motions). The goal of this
 * exercise is to ascertain whether the localizer has been configured properly (note: the pure
 * encoder localizer heading may be significantly off if the track width has not been tuned).
 */
@Config
@TeleOp(group = "drive")
public class LocalizationTest extends LinearOpMode {

   // Turret turret;
    public static int tankTurret = 1;
    Pose2d lastPose = null;
    //DcMotor angle,extender;

    @Override
    public void runOpMode() throws InterruptedException {
        //turret = new Turret(hardwareMap,1);
        /*
        angle = hardwareMap.get(DcMotor.class,"angle");
        extender = hardwareMap.get(DcMotor.class,"extender");
        angle.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        angle.setTargetPosition(angle.getCurrentPosition());
        angle.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        angle.setPower(1);
        extender.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        extender.setTargetPosition(extender.getCurrentPosition());
        extender.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        extender.setPower(1);

         */

        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);

        drive.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        //turret.setPower(0.8);

        waitForStart();


        while (!isStopRequested()) {

            drive.setWeightedDrivePower(
                    new Pose2d(
                            -gamepad1.left_stick_y * 0.4,
                            -gamepad1.left_stick_x * 0.4,
                            -gamepad1.right_stick_x * 0.4
                    )
            );

            drive.update();

            Pose2d poseEstimate = drive.getPoseEstimate();
            telemetry.addData("x", poseEstimate.getX());
            telemetry.addData("y", poseEstimate.getY());
            telemetry.addData("heading", poseEstimate.getHeading());
            telemetry.addData("heading deg",Math.toDegrees(poseEstimate.getHeading()));
            //telemetry.addData("turret",turret.getAngle());
            /*
            if(lastPose != null && tankTurret == 1){
                double robotX = poseEstimate.getX();
                double robotY = poseEstimate.getY();

                double wX = -22.4;
                double wY = 40.1;


                double x = wX - robotX;
                double y = wY - robotY;

                double rot = Math.toDegrees(poseEstimate.getHeading());
                if(rot>180){
                    rot = -(360-rot);
                }
                turret.setRotationAsync(atan2(y,x) * 180 / PI + -rot);



                turret.setRotationAsync(-Math.toDegrees(poseEstimate.getHeading()));
                //double dif = Math.toDegrees(poseEstimate.getHeading()) - Math.toDegrees(lastPose.getHeading());
            }

             */
            telemetry.update();
            lastPose = poseEstimate;
        }
    }
}
