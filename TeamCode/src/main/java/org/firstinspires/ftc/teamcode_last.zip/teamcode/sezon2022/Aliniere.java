package org.firstinspires.ftc.teamcode.sezon2022;

import static java.lang.Math.PI;
import static java.lang.Math.atan2;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@TeleOp(name="Aliniere", group="Linear Opmode")
@Config
//s0Ft ArabEsc
public class Aliniere extends LinearOpMode {

    DcMotorEx tr;

    @Override
    public void runOpMode(){
        DcMotor angle = hardwareMap.get(DcMotor.class,"angle");
        Servo release = hardwareMap.get(Servo.class,"release");
        tr = hardwareMap.get(DcMotorEx.class,"duck");
        tr.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        angle.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        angle.setTargetPosition(0);
        angle.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        angle.setPower(1);
        waitForStart();
        while (opModeIsActive() && !isStopRequested()){
            telemetry.addData("pos",tr.getCurrentPosition());
            telemetry.update();
            if(gamepad1.b){
                angle.setTargetPosition(angle.getCurrentPosition()+15);
            } else if(gamepad1.x){
                angle.setTargetPosition(angle.getCurrentPosition()-15);
            }
            if(gamepad1.y){
                angle.setTargetPosition(angle.getCurrentPosition()+50);
            } else if(gamepad1.a){
                angle.setTargetPosition(angle.getCurrentPosition()-50);
            }
        }
    }
}