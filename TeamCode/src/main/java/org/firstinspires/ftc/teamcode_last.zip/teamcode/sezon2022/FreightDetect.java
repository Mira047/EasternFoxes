
package org.firstinspires.ftc.teamcode.sezon2022;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.TFObjectDetector;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;

@Autonomous(name="Freight Detector", group="Linear Opmode")
@Config
public class FreightDetect extends LinearOpMode {

    Turret turret;
    OpenCvCamera webcam;

    public static double minResultCoef = 0.2f;
    public static int inputSize = 240;
    public static double magnification = 1.4f;
    public static double aspectRatio = 16.0 / 9.0;
    public static int useTracker = 0;

    public String Object = "None";

    private static final String TFOD_MODEL_ASSET = "FreightFrenzy_BCDM.tflite";
    private static final String[] LABELS = {
            "Ball",
            "Cube",
            "Duck"
            //"Marker"
    };
    private static final String VUFORIA_KEY =
            "AW6GYdv/////AAABmeZQFjN+NUrhpwwiNimK5ilSJRT80r6ZVLaw259hhA/Ri+V+qDjXEy2cTiF9ad4x5nKAhSrCqcGw8oyJu6C4lyB0+IzGHaTiU0Qp9E7JwBalpOPfntPuwYfi5ZRi7w1nsY54GwxOmPglpj7Y5uY1zl37ZAQu4OtEOlXB9ouIgtefxObySiv2Nb0vOcvFM5kElgOfOrBPHiDfh0csYiDIfV0FutDpOSFNCGmLZ8ap0ufolGJTP4UeGWF+9hYxFNEryFpxxTarCMY2vwLmA4TzLU5LjEIQyq2CnIgmQVKHjGN4XDyJHxbxGPSpZEYw6Hf9aqtLpLdOiOuheisHPvgtNWBhWyLwYwnx6o6vCUWyYJFW";

    private VuforiaLocalizer vuforia;
    public TFObjectDetector tfod;
    public boolean interrupt = false;
    FtcDashboard dashboard;
    public List<Recognition> updatedRecognitions;
    int use = 0;

    void initVuforia() {
        VuforiaLocalizer.Parameters parameters = new VuforiaLocalizer.Parameters();
        parameters.vuforiaLicenseKey = VUFORIA_KEY;
        parameters.cameraName = hardwareMap.get(WebcamName.class, "Webcam 1");
        //parameters.cameraDirection = CameraDirection.BACK;
        vuforia = ClassFactory.getInstance().createVuforia(parameters);
    }

    void initTf(){
        int tfodMonitorViewId = hardwareMap.appContext.getResources().getIdentifier(
                "tfodMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        TFObjectDetector.Parameters tfodParameters = new TFObjectDetector.Parameters(tfodMonitorViewId);
        tfodParameters.minResultConfidence = (float)minResultCoef;
        tfodParameters.isModelTensorFlow2 = true;
        if(useTracker == 1)
             tfodParameters.useObjectTracker = false;
        else
            tfodParameters.useObjectTracker=true;
        tfodParameters.inputSize = inputSize;
        tfod = ClassFactory.getInstance().createTFObjectDetector(tfodParameters, vuforia);
        tfod.loadModelFromAsset(TFOD_MODEL_ASSET, LABELS);
    }

    Recognition r1;

    @Override
    public void runOpMode() {
        dashboard = FtcDashboard.getInstance();
        dashboard.setTelemetryTransmissionInterval(25);

        turret = new Turret(hardwareMap,1);
        //int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        //webcam = OpenCvCameraFactory.getInstance().createWebcam(hardwareMap.get(WebcamName.class, "Webcam 1"), cameraMonitorViewId);

        initVuforia();
        initTf();

        if (tfod != null) {
            tfod.activate();
            tfod.setZoom(magnification, aspectRatio);
        }

        //Gamepad gm = new Gamepad();
        //gm.start();

        while (!opModeIsActive() && !isStopRequested()) {

            if(gamepad1.a && use == 0){
                use =1;
                new Thread(){
                    @Override
                    public void run(){
                        try{
                            Thread.sleep(1000);
                        }
                        catch (Exception e){

                        }
                        use = 0;
                    }
                }.start();
                if(r1 != null){
                    double ang = r1.estimateAngleToObject(AngleUnit.DEGREES);
                    turret.setRotationAsync(turret.getAngle() + ang);
                }
            }

            if (tfod != null) {
                updatedRecognitions = tfod.getUpdatedRecognitions();
                if (updatedRecognitions != null) {
                    TelemetryPacket packet = new TelemetryPacket();
                    packet.addLine("# Object Detected: "+Integer.toString(updatedRecognitions.size()));
                    packet.addLine("turret: " + turret.getAngle());
                    packet.addLine("use / gm1: " + use + "  " + gamepad1.a);
                    telemetry.addData("# Object Detected", updatedRecognitions.size());
                    int i = 0;
                    for (Recognition recognition : updatedRecognitions) {
                        if(recognition.getLabel().equals("Marker"))
                        {
                            continue;
                        }

                        r1 = recognition;

                        packet.addLine(String.format("label (%d): ", i) + recognition.getLabel());
                        packet.addLine(String.format("  left,top (%d): ", i) + Float.toString(recognition.getLeft()) +
                                " " + Float.toString(recognition.getTop()));
                        packet.addLine(String.format("  right,bottom (%d): ", i) + Float.toString(recognition.getRight()) +
                                " " + Float.toString(recognition.getBottom()));
                        packet.addLine("  estimated angle: " + recognition.estimateAngleToObject(AngleUnit.DEGREES));

                        float centerX = (recognition.getLeft() + recognition.getRight()) / 2;
                        float centerY = (recognition.getTop() + recognition.getBottom()) / 2;
                        packet.addLine("  center: " + centerX + " " + centerY);

                        //float screenCenterX = 720/2;

                        //double ang = recognition.estimateAngleToObject(AngleUnit.DEGREES);
                        //turret.setRotation(turret.getAngle() + ang);

                        telemetry.addData(String.format("label (%d)", i), recognition.getLabel());
                        telemetry.addData(String.format("  left,top (%d)", i), "%.03f , %.03f",
                                recognition.getLeft(), recognition.getTop());
                        telemetry.addData(String.format("  right,bottom (%d)", i), "%.03f , %.03f",
                                recognition.getRight(), recognition.getBottom());
                        i++;
                    }
                    telemetry.update();
                    dashboard.sendTelemetryPacket(packet);
                }
            }
        }
        waitForStart();
        tfod.shutdown();
    }

    private class Gamepad implements Runnable{
        private Thread localT;
        int use = 0;

        @Override
        public void run() {
            while (!opModeIsActive() && !isStopRequested()) {
                if(gamepad1.a && use == 0){
                    use =1;
                    new Thread(){
                        @Override
                        public void run(){
                            try{
                                Thread.sleep(1000);
                            }
                            catch (Exception e){

                            }
                            use = 0;
                        }
                    }.start();
                    if(updatedRecognitions != null){
                        Recognition recognition = updatedRecognitions.get(0);
                        double ang = recognition.estimateAngleToObject(AngleUnit.DEGREES);
                        turret.setRotation(turret.getAngle() + ang);
                    }
                }
            }
        }
        public void start(){
            if( localT == null ) {
                localT = new Thread(this);
                localT.start();
            }
        }
    }

}
