package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class Launcher {
    public Servo ramp1_motor = null;
    public Servo ramp2_motor = null;
    public Servo ramp_mid = null;
    public  Servo wob1 = null;
    public DcMotor motLeft = null;
    public  DcMotor motRight = null;
    public double launch_spd;
    public double offset = 0.0;

    public DcMotor intake;
    public  DcMotor wobArm;
    public  Servo wobDrop;

    public Launcher(HardwareMap map) {
            ramp1_motor = map.get(Servo.class, "rampPushLeft");
            ramp2_motor = map.get(Servo.class, "rampPushRight");
            ramp_mid = map.get(Servo.class,"rampPushMid");
            motLeft = map.get(DcMotor.class,"rampLeft");
            motRight = map.get(DcMotor.class,"rampRight");
            wob1 = map.get(Servo.class,"wob1");
            intake = map.get(DcMotor.class,"intake");
                wobArm = map.get(DcMotor.class,"wobArm");
                wobDrop = map.get(Servo.class,"wobDrop");
                wobArm.setTargetPosition(0);
                wobArm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        ramp1_motor.setPosition(0.83);
        ramp2_motor.setPosition(0.17);
        wob1.setPosition(0);
    }

    public double p1 = -0.58;
    public double p2 = 0.55;

    void sleep(int ms){
        try{
            Thread.sleep(ms);
        }catch (InterruptedException e){

        }
    }

    public void launchCorrector() {
        ramp_mid.setPosition(0.2);
        sleep(300);
        ramp_mid.setPosition(0);
    }

    public  void launchRing(){
        /*motLeft.setPower(-0.48);
        motRight.setPower(0.45);
        sleep(100);
        ramp_mid.setPosition(0.14);
        sleep(500);
        ramp_mid.setPosition(0.14);
        ramp1_motor.setPosition(1);
        ramp2_motor.setPosition(0);
        sleep(500);
        ramp_mid.setPosition(0);
        ramp1_motor.setPosition(0.83);
        ramp2_motor.setPosition(0.17);
        motLeft.setPower(0);
        motRight.setPower(0);*/
        motLeft.setPower(p1);
        motRight.setPower(p2);
        ramp_mid.setPosition(0.2);
        sleep(300);
        ramp_mid.setPosition(0);
        sleep(200);
        ramp1_motor.setPosition(1);
        ramp2_motor.setPosition(0);
        sleep(300);
        ramp1_motor.setPosition(0.83);
         ramp2_motor.setPosition(0.17);
         sleep(50);
        motLeft.setPower(0);
        motRight.setPower(0);
    }

    public  void addPow(double f){
        p1 -= f;
        if(p1<-0.98) p1=-0.98;
        else if(p1>-0.25) p1 = -0.25;
        p2 += f;
        if(p2>0.95) p2 = 0.95;
        else if(p2<0.23) p2= 0.23;
    }

    public  void setPow(double d,double d2){
        p1 = d;
        p2 = d2;
    }

    public void launch (double launch_speed1,double launch_speed2,double l3) {
        ramp1_motor.setPosition(launch_speed1);
        ramp2_motor.setPosition(launch_speed2);
        ramp_mid.setPosition(l3);
    }

    public  void loadRing(){
        ramp1_motor.setPosition(0.88);
        ramp2_motor.setPosition(0.14);
    }

    public  void unloadRing(){
        ramp1_motor.setPosition(1);
        ramp2_motor.setPosition(0);
    }

    public void stop_all () {
        ramp1_motor.setPosition(0);
        ramp2_motor.setPosition(0);
    }

}
