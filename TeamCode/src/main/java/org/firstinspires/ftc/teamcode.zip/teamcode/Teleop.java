package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp

public class Teleop extends LinearOpMode {

    DcMotor forward_right;
    DcMotor forward_left;
    DcMotor backward_right;
    DcMotor backward_left;





    @Override
    public void runOpMode() {
        forward_right = hardwareMap.get(DcMotor.class, "front_right");
        forward_left= hardwareMap.get(DcMotor.class, "front_left");
        backward_right = hardwareMap.get(DcMotor.class, "back_right");
        backward_left = hardwareMap.get(DcMotor.class, "back_left");

        waitForStart ();
        while (opModeIsActive ()) {
            forward_right.setPower(0.1);
            forward_left.setPower(0.1);
            backward_right.setPower(0.1);
            backward_left.setPower(0.1);
        }
    }
}

