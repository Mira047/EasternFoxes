package org.firstinspires.ftc.teamcode;

import android.hardware.camera2.params.BlackLevelPattern;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;


import java.util.Set;

public class Motors {
    public DcMotor FL_motor = null;
    public DcMotor FR_motor = null;
    public DcMotor BL_motor = null;
    public DcMotor BR_motor = null;

    public static int FL = 1;
    public static int FR = 2;
    public static int BL = 3;
    public static int BR = 4;

    private int FLP = 0;
    private int FRP = 0;
    private int BLP = 0;
    private int BRP = 0;

    private double direction_X ( double alpha) {
        return Math.sin( Math.toRadians (alpha)  );
    }
    private double direction_Y ( double alpha) {
        return  Math.cos( Math.toRadians (alpha)  );
    }

    public Motors(HardwareMap map, boolean isAutonomy){
        FL_motor  = map.get(DcMotor.class, "front_left");
        FR_motor = map.get(DcMotor.class, "front_right");
        BL_motor  = map.get(DcMotor.class, "back_left");
        BR_motor = map.get(DcMotor.class, "back_right");
        FL_motor.setDirection(DcMotor.Direction.REVERSE);
        FR_motor.setDirection(DcMotor.Direction.FORWARD);
        BR_motor.setDirection(DcMotor.Direction.FORWARD);

        BL_motor.setDirection(DcMotor.Direction.REVERSE);
        if(isAutonomy) {

            FL_motor.setTargetPosition (FL_motor.getCurrentPosition ());
            FR_motor.setTargetPosition (FR_motor.getCurrentPosition ());
            BL_motor.setTargetPosition (BL_motor.getCurrentPosition ());
            BR_motor.setTargetPosition (BR_motor.getCurrentPosition ());
            
            FL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
            FR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
            BL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
            BR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
        } else {

            FL_motor.setMode (DcMotor.RunMode.RUN_USING_ENCODER);
            FR_motor.setMode (DcMotor.RunMode.RUN_USING_ENCODER);
            BL_motor.setMode (DcMotor.RunMode.RUN_USING_ENCODER);
            BR_motor.setMode (DcMotor.RunMode.RUN_USING_ENCODER);
        }
    }


    public void motor_restart (HardwareMap map)
    {

        FL_motor  = map.get(DcMotor.class, "front_left");
        FR_motor = map.get(DcMotor.class, "front_right");
        BL_motor  = map.get(DcMotor.class, "back_left");
        BR_motor = map.get(DcMotor.class, "back_right");

        FL_motor.setDirection(DcMotor.Direction.REVERSE);
        FR_motor.setDirection(DcMotor.Direction.FORWARD);
        BR_motor.setDirection(DcMotor.Direction.FORWARD);
        BL_motor.setDirection(DcMotor.Direction.REVERSE);

        FL_motor.setTargetPosition (FL_motor.getCurrentPosition ());
        FR_motor.setTargetPosition (FR_motor.getCurrentPosition ());
        BL_motor.setTargetPosition (BL_motor.getCurrentPosition ());
        BR_motor.setTargetPosition (BR_motor.getCurrentPosition ());

        FL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
        FR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
        BL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
        BR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);


    }



    public void stop_motors ()
    {
        FL_motor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        FR_motor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        BL_motor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        BR_motor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    }

    public void runMotor (int mot_number, double power, int dist){
        switch (mot_number){
            case 1://FL_motor
                FL_motor.setPower (power);
                FL_motor.setTargetPosition (dist + FL_motor.getTargetPosition ());
                FL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
                break;
            case 2://FR_motor
                FR_motor.setPower (power);
                FR_motor.setTargetPosition (dist + FR_motor.getTargetPosition ());
                FR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
                break;
            case 3://BL_motor
                BL_motor.setPower (power);
                BL_motor.setTargetPosition (dist + BL_motor.getTargetPosition ());
                BL_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
                break;
            case 4://BR_motor
                BR_motor.setPower (power);
                BR_motor.setTargetPosition (dist + BR_motor.getTargetPosition ());
                BR_motor.setMode (DcMotor.RunMode.RUN_TO_POSITION);
                break;
        }
    }

    private double rotate (double speed ) {
        return Math.max ( 0.05, speed );

    }

    public void reboot (HardwareMap map)
    {
        stop_motors ();
        motor_restart (map);
    }
    public boolean isRunning(){
        if(FL_motor.isBusy ())
            return true;
        if(BL_motor.isBusy ())
            return true;
        if(FR_motor.isBusy ())
            return true;
        if(BR_motor.isBusy ())
            return true;
        return false;
    }

    private  double max_spd_calc (double angle  )
    {
        return Math.abs( Math.max (  Math.max(-direction_Y (angle)+direction_X (angle),direction_Y (angle)+direction_X (angle))
                , Math.max (direction_Y (angle)+direction_X (angle) ,-direction_Y (angle)+direction_X (angle) )      ));
////face maimxul dintre viteze :));
        ///kys nita
    }

    public void runAngle(double angle, double def_speed, double rotate){
        FL_motor.setPower ((-direction_Y (angle)+direction_X (angle) )* def_speed/max_spd_calc(angle)  +rotate  );
        FR_motor.setPower ((direction_Y (angle)+direction_X (angle) )*def_speed/max_spd_calc(angle)  -rotate );
        BL_motor.setPower ((direction_Y (angle)+direction_X (angle)  )* def_speed/max_spd_calc(angle) +rotate  );
        BR_motor.setPower ((-direction_Y (angle)+direction_X (angle)  )* def_speed/max_spd_calc(angle)  -rotate );
    }

    public void run_angle_auto(double angle , double def_speed, int tick_dist ) {

        ///NU MERGE PERNTU 45 DE GRADE
        /// nici pentru alte grade nu merge.....

        FL_motor.setPower ((-direction_Y (angle)+direction_X (angle) )* def_speed/max_spd_calc(angle)  );
        FR_motor.setPower ((direction_Y (angle)+direction_X (angle) )*def_speed/max_spd_calc(angle)  );
        BL_motor.setPower ((direction_Y (angle)+direction_X (angle)  )* def_speed/max_spd_calc(angle) );
        BR_motor.setPower ((-direction_Y (angle)+direction_X (angle)  )* def_speed/max_spd_calc(angle) );

        int T1 =  (int)(tick_dist/   (-direction_Y (angle)+direction_X (angle) )* def_speed/max_spd_calc(angle)) ;
        int T2 = (int)(tick_dist/   (direction_Y (angle)+direction_X (angle) )* def_speed/max_spd_calc(angle));
        FL_motor.setTargetPosition ( T2 );
        FR_motor.setTargetPosition ( T1 );
        BL_motor.setTargetPosition ( T1 );
        BR_motor.setTargetPosition ( T2 );
    }

    public void run_fwd(int t_dist, double spd)
    {
        FL_motor.setPower (spd);
        FR_motor.setPower (spd);
        BL_motor.setPower (spd );
        BR_motor.setPower (spd);

        FL_motor.setTargetPosition ( t_dist );
        FR_motor.setTargetPosition ( t_dist );
        BL_motor.setTargetPosition ( t_dist );
        BR_motor.setTargetPosition ( t_dist );


    }


    private double spdc;
    private double t1;

    public void run_fwd_acc(int t_dist, double spd, int tdist_acc)
    {

        spdc=0;
        t1=Math.abs (spd/tdist_acc);
        int x,y;


        FL_motor.setTargetPosition ( t_dist );
        FR_motor.setTargetPosition ( t_dist );
        BL_motor.setTargetPosition ( t_dist );
        BR_motor.setTargetPosition ( t_dist );

        int p=0;
        if(spd<0)p=-1;
        else p=1;
        y=-1;

        do {
            x=Math.abs(FL_motor.getCurrentPosition ());
            if(x>y) {
                if (Math.abs (x) <Math.abs (tdist_acc)){
                    spdc += t1*p;
                }
                if (Math.abs (x) > Math.abs( t_dist- tdist_acc)) spdc -= t1*p;
            }


            FL_motor.setPower (Math.max ( Math.abs (spdc),0.08));
            FR_motor.setPower (Math.max ( Math.abs (spdc),0.08));
            BL_motor.setPower (Math.max ( Math.abs (spdc),0.08));
            BR_motor.setPower (Math.max ( Math.abs (spdc),0.08));

            y=Math.abs (x);
        }while(isRunning ());

    }

    public void run_slide_acc(int t_dist, double spd, int tdist_acc)
    {

        spdc=0;
        t1=Math.abs (spd/tdist_acc);
        int x,y;


        FL_motor.setTargetPosition ( -t_dist );
        FR_motor.setTargetPosition ( t_dist );
        BL_motor.setTargetPosition ( t_dist );
        BR_motor.setTargetPosition ( -t_dist );

        int p=0;
        if(spd<0)p=-1;
        else p=1;
        y=-1;

        do {
            x=Math.abs(FR_motor.getCurrentPosition ());
            if(x>y) {
                if (Math.abs (x) <Math.abs (tdist_acc)){
                    spdc += t1*p;
                }
                if (Math.abs (x) > Math.abs( t_dist- tdist_acc)) spdc -= t1*p;
            }


            FL_motor.setPower (-Math.max (Math.abs (spdc),0.08));
            FR_motor.setPower (Math.max (Math.abs (spdc),0.08));
            BL_motor.setPower (Math.max (Math.abs (spdc),0.08));
            BR_motor.setPower (-Math.max (Math.abs (spdc),0.08));

            y=Math.abs (x);
        }while(isRunning ());

    }



    public void rotate(int t_dist, double spd)
    {

        FL_motor.setTargetPosition ( -t_dist );
        FR_motor.setTargetPosition ( t_dist );
        BL_motor.setTargetPosition ( -t_dist );
        BR_motor.setTargetPosition ( t_dist );

        FL_motor.setPower (-spd);
        BL_motor.setPower (-spd);
        FR_motor.setPower (spd);
        BR_motor.setPower (spd);



    }
}
