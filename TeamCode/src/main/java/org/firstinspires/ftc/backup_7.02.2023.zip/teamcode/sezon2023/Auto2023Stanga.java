package org.firstinspires.ftc.teamcode.sezon2023;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.sezon2022.CameraRecognition;
import org.firstinspires.ftc.teamcode.sezon2022.HardwareTesterInterpreter;
import org.firstinspires.ftc.teamcode.sezon2022.PipeLineDetector;

@Autonomous(name="Auto2023 Stanga", group="Linear Opmode")
@Config
public class Auto2023Stanga extends LinearOpMode {

    public String[] script = new String[]{
            "servo clawRotate 0.54",
            "servo clawLeft 0.55",
            "servo clawRight 0.44",
            "wait 200",
            "go posh 27.5 0 -38",
            "motor lift 0 reset_position",
            "motor lift 1 power",
            "motor lift 760 position",
            "motor brat 0 reset_position",
            "motor brat 0.55 power",
            "motor brat -2250 position",
            "servo clawRotate 0.345",
            "wait 1500",
            "motor lift 400 position",
            "wait 400",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 600",
            "servo clawLeft 0.525",
            "servo clawRight 0.475",
            "servo clawRotate 0.55",
            "motor lift 0 position",
            "motor brat 0 position",
            "wait 1000",
            "go posh 54 2 -82"
            /*
            "motor lift 860 position",
            "servo clawRotate 0.506",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "go posh 54 28.3 -80",
            "servo clawLeft 0.555",
            "servo clawRight 0.44",
            "wait 300",
            "motor lift 1500 position",
            "wait 500",
            "servo clawRotate 0.56",
            "wait 700",
            "motor lift 1570 position",
            "motor brat 0.6 power",
            "motor brat -2000 position",
            "servo clawRotate 0.3635",
            "wait 1000",
            "go posh 53.2 1 -41.2",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 500",
            "servo clawLeft 0.55",
            "servo clawRight 0.44",
            "servo clawRotate 0.5",
            "motor brat 0 position",
            "motor lift 720 position",
            "servo clawRotate 0.506",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 500",
            "go posh 54 28.3 -80",
            "servo clawLeft 0.555",
            "servo clawRight 0.44",
            "wait 300",
            "motor lift 1500 position",
            "wait 1000",
            "servo clawRotate 0.56",
            "wait 700",
            "motor lift 1570 position",
            "motor brat 0.6 power",
            "motor brat -2000 position",
            "servo clawRotate 0.3635",
            "wait 800",
            "go posh 53.2 1 -41.2",
            "wait 199",
            "servo clawLeft 0.3",
            "servo clawRight 0.7",
            "wait 200",
            "motor brat 0 position",
            "motor lift 0 position",
            "servo clawRotate 0.55",
            "wait 500"
            */
    };
    SampleMecanumDrive drive;
    CameraRecognition cameraRecognition;
    int caz;

    @Override
    public void runOpMode() throws InterruptedException {
        drive = new SampleMecanumDrive(hardwareMap);
        HardwareTesterInterpreter.initHWI(this,hardwareMap,telemetry,drive);

        cameraRecognition = new CameraRecognition(hardwareMap,telemetry,"red");
        cameraRecognition.initCamera();
        cameraRecognition.start(1);

        while(!opModeIsActive() && !isStopRequested()){
            if(cameraRecognition.detector.caz == PipeLineDetector.Status.VERDE1){
                caz = 1;
            }
            else if(cameraRecognition.detector.caz == PipeLineDetector.Status.ROSU2){
                caz = 2;
            } else if(cameraRecognition.detector.caz == PipeLineDetector.Status.ALBASTRU3){
                caz = 3;
            }
            telemetry.addData("detected", caz);
            telemetry.update();

        }

        waitForStart ();
        cameraRecognition.stop();
        telemetry.addData("Facem cazul",caz);

        while (opModeIsActive())
        {
            main();
            break;
        }
    }



    void Wait(int ms){
        try{
            Thread.sleep(ms);
        }catch (Exception ex){

        }
    }


    private  void main(){
        for(int i=0;i<script.length;i++){
            if(isStopRequested())
                break;
            HardwareTesterInterpreter.interpretCommand(script[i]);
        }
        if(isStopRequested())
            return;
        if(caz == 1){
            HardwareTesterInterpreter.interpretCommand("go posh 51 26 0");
        } else if(caz == 2){
            HardwareTesterInterpreter.interpretCommand("go posh 51 0 0");
        } if(caz == 3){
            HardwareTesterInterpreter.interpretCommand("go posh 51 -27 0");
        }
    }
}
