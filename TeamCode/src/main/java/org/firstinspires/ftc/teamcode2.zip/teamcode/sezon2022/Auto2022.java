package org.firstinspires.ftc.teamcode.sezon2022;

import android.hardware.camera2.params.BlackLevelPattern;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.ColorSensor;

import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoController;

import org.apache.commons.math3.geometry.euclidean.twod.Line;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.opencv.core.Mat;

@Autonomous(name="Auto2022", group="Linear Opmode")
@Config
public class Auto2022 extends LinearOpMode {

    public  static int caz = 2;
    SampleMecanumDrive drive;
    DcMotor mosor;
    DcMotor biceps;
    Servo claw;
    boolean notOpen = true;
    Trajectory traj;
    Trajectory traj2;
    Servo mosorFlip;
    DcMotor duck;
    Servo intake1,intake2;
    CameraRecognition cameraRecognition;

    void rotateDuck(){
        duck.setPower(0.4f);
        duck.setTargetPosition(-3000);
        while (!(duck.getCurrentPosition() >= -3000 - 30 && duck.getCurrentPosition() <= -3000 + 30)){
            Wait(10);
        }
        duck.setPower(0);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        notOpen = true;
        drive = new SampleMecanumDrive(hardwareMap);
        mosor = hardwareMap.get(DcMotor.class,"mosor");
        biceps = hardwareMap.get(DcMotor.class,"biceps");
        duck = hardwareMap.get(DcMotor.class,"duck");
        mosorFlip = hardwareMap.get(Servo.class,"mosorFlip");
        intake1 = hardwareMap.get(Servo.class,"intake_servo1");
        intake2 = hardwareMap.get(Servo.class,"intake_servo2");
        mosor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        duck.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        biceps.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        claw = hardwareMap.get(Servo.class,"claw");
        claw.setPosition(clawClose);
        duck.setTargetPosition(0);
        duck.setMode(DcMotor.RunMode.RUN_TO_POSITION);




        double p= 0.5;
        mosorFlip.setPosition(p);
        mosor.setTargetPosition(-2300);
        mosor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        mosor.setPower(0.8);
        while(p < 1){
            p+=0.01;
            sleep(55);
            mosorFlip.setPosition(p);
        }

        while (!(mosor.getCurrentPosition() >= -2300 - 30 && mosor.getCurrentPosition() <= -2300 + 30)){
            sleep(10);
        }



        mosor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        mosor.setTargetPosition(mosor.getCurrentPosition());
        mosor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        cameraRecognition = new CameraRecognition(hardwareMap,telemetry,"red");
        cameraRecognition.initCamera();
        cameraRecognition.start(1);


        waitForStart ();

        caz = cameraRecognition.getCase();
        telemetry.addLine("Case: " + Integer.toString(caz));
        telemetry.update();
        cameraRecognition.stop();

        openClaw();

        claw.setPosition(clawClose);

            while (opModeIsActive()) {
                main();
                break;
            }
    }

    public  static int case1pos = -1350;
    public static  int case2pos = -3100;
    public static int case3pos = -4600;
    public static  double clawClose = 0;
    public  static  double clawOpen = 0.1;
    public static int thisCasePos = 0;

        public  static  double TargetX = 50;
    public  static  double TargetY = -68;

    public  static  double TargetFw = 42;
    public static double TargetFw3 = 39;

    public  static  double TargetX2 = 10;
    public  static  double TargetY2 = 33;

    public  static  double posEndX = -40;
    public  static  double posEndY = -195;

    public  static  double angleRotate = -75;
    public static double angleRotate2 = -82;
    public  static  double angleDuck = 0;

    /*
    public  static  double TargetX = 50;
    public  static  double TargetY = -112;

    public  static  double TargetFw = 42;
    public static double TargetFw3 = 39;

    public  static  double TargetX2 = 4;
    public  static  double TargetY2 = 43.4;

    public  static  double posEndX = 0.08;
    public  static  double posEndY = -195;

    public  static  double angleRotate = 3;
    public  static  double angleDuck = -45;


     */

    public  static  int bicepsPos = 500;
    public  static  double bicepsPower = 0.22;

    void Wait(int ms){
        try{
            Thread.sleep(ms);
        }catch (Exception ex){

        }
    }

    void openClaw(){
        if(caz == 1){
            thisCasePos = case1pos;
        } else if(caz == 2){
            thisCasePos = case2pos;
        } else if (caz == 3){
            thisCasePos = case3pos;
        }
        mosor.setTargetPosition(thisCasePos);
        mosor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        mosor.setPower(0.5);
        while (!(mosor.getCurrentPosition() >= thisCasePos - 30 && mosor.getCurrentPosition() <= thisCasePos + 30)){
            Wait(10);
        }
    }


    private  void main(){
        Thread th = new Thread(){
            @Override
            public void run() {
                while (opModeIsActive() && !isStopRequested()) {
                    Pose2d poseEstimate = drive.getPoseEstimate();
                    telemetry.addData("x", poseEstimate.getX());
                    telemetry.addData("y", poseEstimate.getY());
                    telemetry.addData("heading", poseEstimate.getHeading());
                    telemetry.update();
                }
            }
        };
        th.start();


        //drive.turn(Math.toRadians(-45));
        try {
            //Trajectory traj; // drive.trajectoryBuilder(new Pose2d()).forward(100 / 2.54).build();
            if(caz == 3) {
                traj = drive.trajectoryBuilder(new Pose2d().plus(new Pose2d(0, 0, Math.toRadians(angleRotate2))))
                        .lineTo(new Vector2d(TargetX / 2.54, TargetY / 2.54))
                        .build();
                drive.turn(Math.toRadians(angleRotate2));
            } else {
                traj = drive.trajectoryBuilder(new Pose2d().plus(new Pose2d(0, 0, Math.toRadians(angleRotate))))
                        .lineTo(new Vector2d(TargetX / 2.54, TargetY / 2.54))
                        .build();
                drive.turn(Math.toRadians(angleRotate));
            }
            drive.followTrajectory(traj);
            drive.update();
            biceps.setTargetPosition(bicepsPos);
            biceps.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            biceps.setPower(bicepsPower);
            Pose2d pos = drive.getPoseEstimate();
            /*
            Trajectory tr2 = drive.trajectoryBuilder(pos).forward(m_TargetFw / 2.54).build();
            drive.followTrajectory(tr2);
            drive.update();
            */
            Pose2d poseEstimate = drive.getPoseEstimate();


            //claw.setPosition(clawOpen);

            int x= 0;
            while(x<1000) {
                intake1.setPosition(0.65);
                intake2.setPosition(0.35);
                sleep(10);
                x+=10;
            }
            intake1.setPosition(0.5);
            intake2.setPosition(0.5);


            /*
            Trajectory tr3 = drive.trajectoryBuilder(drive.getPoseEstimate()).lineToLinearHeading(pos).build();
            drive.followTrajectory(tr3);
            drive.update();

             */

            //drive.turn(Math.toRadians(-angleRotate + angleDuck));


            traj2 = drive.trajectoryBuilder(drive.getPoseEstimate())
                    .lineToConstantHeading(new Vector2d(TargetX2/2.54,TargetY2/2.54))
                    .build();
            drive.followTrajectory(traj2);
            drive.update();

            rotateDuck();

            if(caz == 3)
                drive.turn(Math.toRadians(-90 - angleRotate2));
            else
                drive.turn(Math.toRadians(-90 - angleRotate));
            Trajectory trajFinal = drive.trajectoryBuilder(drive.getPoseEstimate())
                    .lineToLinearHeading(new Pose2d(posEndX/2.54,posEndY/2.54,Math.toRadians(-90)))
                    .build();

            drive.followTrajectory(trajFinal);
            drive.update();

            trajFinal = drive.trajectoryBuilder(drive.getPoseEstimate())
                    .lineToLinearHeading(new Pose2d((posEndX+35)/2.54,(posEndY-35)/2.54,Math.toRadians(-45)))
                    .build();
            drive.followTrajectory(trajFinal);
            drive.update();

            Storage.autoPose = drive.getPoseEstimate();

            mosor.setTargetPosition(0);
            mosor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            mosor.setPower(0.8);
            Wait(5000);

        }
        catch (Exception ex){
            telemetry.addLine(ex.toString());
            telemetry.update();
        }
    }
}
