package org.firstinspires.ftc.teamcode.sezon2022;

import com.acmerobotics.roadrunner.geometry.Pose2d;

public class Storage {
    public static Pose2d autoPose = new Pose2d(0,0,0);
}
