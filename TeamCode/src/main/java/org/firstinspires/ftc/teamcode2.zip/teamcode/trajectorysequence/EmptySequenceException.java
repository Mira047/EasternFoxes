package org.firstinspires.ftc.teamcode.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
