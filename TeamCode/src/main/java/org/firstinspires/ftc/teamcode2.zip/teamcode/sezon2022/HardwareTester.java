package org.firstinspires.ftc.teamcode.sezon2022;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.drive.Drive;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoControllerEx;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import com.qualcomm.robotcore.hardware.VoltageSensor;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.util.DashboardUtil;
import org.opencv.core.Mat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.stream.Collectors;

@Config
@Autonomous
public class HardwareTester extends LinearOpMode {

    public static int useRR = 1;
    Turret turret;
    FtcDashboard dashboard;

    double getBatteryVoltage(){
        double result = Double.POSITIVE_INFINITY;
        for(VoltageSensor sensor: hardwareMap.voltageSensor){
            double voltage = sensor.getVoltage();
            if(voltage>0){
                result = Math.min(result,voltage);
            }
        }
        return result;
    }

    @Override
    public void runOpMode() throws InterruptedException {
        dashboard = FtcDashboard.getInstance();
        turret = new Turret(hardwareMap,1);
        if(useRR == 1)
        drive = new SampleMecanumDrive(hardwareMap);
        waitForStart ();
        while (opModeIsActive ()) {
            main();
            break;
        }
    }

    void Sleep(int ms){
        try{
            Thread.sleep(ms);
        }catch (InterruptedException e){

        }
    }


    public String request(){
        try {
            URL url = new URL("http://192.168.43.219:4444/cmd");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            String s = "";
            while ((line = in.readLine()) != null) {
                s += line + "\n";
            }
            con.disconnect();
            return s;
        }
        catch (Exception e){
            telemetry.addData("error",e.toString());
            telemetry.update();
            return "";
        }
    }

    Servo intakeHelper1,intakeHelper2;
    SampleMecanumDrive drive;
    float drivePower = 0.3f;
    boolean traj = false;

    String currentScript="";

    public void interpretScript(String script){
        currentScript = script;
        String[] lines = script.split("\\n");
        String a="";
        for(int i=0;i<lines.length;i++) {
            a += lines[i] + "@";
        }
        telemetry.addData("data: ",a);
        telemetry.update();
        for(int i=0;i<lines.length;i++){
            if(lines[i] == "")
                continue;
            if(opModeIsActive() == false || isStopRequested())
                break;
            interpretCommand(lines[i]);
        }
    }

    public void interpretCommand(String s){
        String[] args = s.split(" ");
        if(args[0].equals("go")){
            traj =true;
            if(args[1].equals("fw") || args[1].equals("forward")){
                double distance = Double.valueOf(args[2]);
                Trajectory trajectory = drive.trajectoryBuilder(new Pose2d())
                        .forward(distance/2.54d)
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("bw") || args[1].equals("backward")){
                double distance = Double.valueOf(args[2]);
                Trajectory trajectory = drive.trajectoryBuilder(new Pose2d())
                        .back(distance/2.54d)
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("left") || args[1].equals("l")){
                double distance = Double.valueOf(args[2]);
                Trajectory trajectory = drive.trajectoryBuilder(new Pose2d())
                        .strafeLeft(distance/2.54d)
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("right") || args[1].equals("r")){
                double distance = Double.valueOf(args[2]);
                Trajectory trajectory = drive.trajectoryBuilder(new Pose2d())
                        .strafeRight(distance/2.54d)
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("rot")){
                double angle = Double.valueOf(args[2]);
                drive.turn(Math.toRadians(angle));
            } else if(args[1].equals("test")) {
                double distance = Double.valueOf(args[2]);
                //DriveConstants.setStraight();
                Trajectory trajectory = drive.trajectoryBuilder(new Pose2d())
                        .strafeRight(distance / 2.54d)
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("pos")){
                Trajectory trajectory = drive.trajectoryBuilder(drive.getPoseEstimate())
                        .lineTo(new Vector2d(Double.valueOf(args[2]),Double.valueOf(args[3])))
                        .build();
                drive.followTrajectory(trajectory);
            }
            else if(args[1].equals("posh")){
                Trajectory trajectory = drive.trajectoryBuilder(drive.getPoseEstimate())
                        .lineToLinearHeading(new Pose2d(Double.valueOf(args[2]),Double.valueOf(args[3]),Math.toRadians(Double.valueOf(args[4]))))
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("spline")) {
                Trajectory trajectory = drive.trajectoryBuilder(drive.getPoseEstimate())
                        .splineTo(new Vector2d(Double.valueOf(args[2]), Double.valueOf(args[3])), Math.toRadians(Double.valueOf(args[4])))
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("spline_heading")){
                Trajectory trajectory = drive.trajectoryBuilder(drive.getPoseEstimate())
                        .splineToLinearHeading(new Pose2d(Double.valueOf(args[2]),Double.valueOf(args[3]),Double.valueOf(args[4])),Math.toRadians(Double.valueOf(args[5])))
                        .build();
                drive.followTrajectory(trajectory);
            } else if(args[1].equals("set")){
                if(args[2].equals("speed")){
                    DriveConstants.MAX_ACCEL = Double.parseDouble(args[3]);
                    DriveConstants.MAX_VEL = Double.parseDouble(args[3]);
                } else if(args[2].equals("pid")){

                }
            }
            drive.update();
            traj=false;
        }
        else if(args[0].equals("servo")){
            try {
                ServoImplEx sv = hardwareMap.get(ServoImplEx.class,args[1]);
                if(args[2].equals("close")){
                    sv.getController().pwmDisable();
                } else {
                    //sv.getController().pwmEnable();
                    sv.setPosition(Float.parseFloat(args[2]));
                }
            }catch (Exception a){
                telemetry.addLine(a.toString());
                telemetry.update();
            }
        }
        else if(args[0].equals("turret")) {
            try{
                if(args.length == 2)
                    turret.setRotationAsync(Double.parseDouble(args[1]));
                else if(args.length == 3 && args[2].equals("wait"))
                    turret.setRotation(Double.parseDouble(args[1]));
                else if(args.length == 4 && args[2].equals("wait")){
                    double angTresh = Double.parseDouble(args[3]);
                    turret.setRotationAsync(Double.parseDouble(args[1]));
                    while (!(turret.getAngle() >= turret.getTargetAngle() - angTresh && turret.getAngle() <= turret.getTargetAngle() + angTresh)){
                        Sleep(0);
                    }
                }
                else if(args.length == 3 && args[2].equals("power")){
                    turret.setPower(Double.parseDouble(args[1]));
                } else if(args.length == 5 && args[1].equals("pid")){
                    turret.setPid(Double.parseDouble(args[2]),Double.parseDouble(args[3]),Double.parseDouble(args[4]));
                }
            }
            catch (Exception a){
                telemetry.addLine(a.toString());
                telemetry.update();
            }
        }
        else if(args[0].equals("motor")){
            // motor mosor 100 position
                try {
                    DcMotor dc = hardwareMap.get(DcMotor.class, args[1]);
                    if(args[3].equals("position")) {
                        if(args[2].equals("wait")) {
                            int tresh = 0;
                            if(args.length>4){
                                tresh = Integer.parseInt(args[4]);
                            }
                            int p = dc.getCurrentPosition();
                            int t = dc.getTargetPosition();
                            while (!(p >= t - tresh && p <= t + tresh)){
                                p = dc.getCurrentPosition();
                                telemetry.addData(args[1],p);
                                telemetry.update();
                                Sleep(1);
                            }
                        } else {
                            dc.setTargetPosition(Integer.parseInt(args[2]));
                            dc.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                        }
                    } else if(args[3].equals("power")){
                        dc.setPower(Float.parseFloat(args[2]));
                    } else if(args[3].equals("normal")){
                        dc.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                    }
                    else if(args[3].equals("reset_position")){
                        dc.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                    } else if(args[3].equals("fw")){
                        dc.setDirection(DcMotor.Direction.FORWARD);
                    } else if(args[3].equals("bw")){
                        dc.setDirection(DcMotor.Direction.REVERSE);
                    }
                    telemetry.addData("motor " + args[1] +" update: ",args[3] +"/"+args[2]);
                    telemetry.update();
                } catch (Exception a) {
                    telemetry.addLine(a.toString());
                    telemetry.update();
                }
        }
        else if(args[0].equals("rr")){
            try {
                if (args[1].equals("speed")) {
                    DriveConstants.MAX_VEL = Double.parseDouble(args[2]);
                } else if (args[1].equals("accel")) {
                    DriveConstants.MAX_ACCEL = Double.parseDouble(args[2]);
                } else if (args[1].equals("kv")) {
                    DriveConstants.kV = Double.parseDouble(args[2]);
                } else if (args[1].equals("ka")) {
                    DriveConstants.kA = Double.parseDouble(args[2]);
                }
            }catch (Exception a){
                telemetry.addLine(a.toString());
                telemetry.update();
            }
        }
        else if(args[0].equals("wait")){
            try{
                Sleep(Integer.parseInt(args[1]));
            } catch (Exception a){
                telemetry.addLine(a.toString());
                telemetry.update();
            }
        }
    }

    public void main(){

        /*
        intakeHelper1 = hardwareMap.get(Servo.class,"intakeHelper1");
        intakeHelper2 = hardwareMap.get(Servo.class,"intakeHelper2");
        */

        Thread th = new Thread() {
            @Override
            public void run() {
                while (opModeIsActive() && !isStopRequested()){
                    String s = request();
                    if(s == "" || s == null) {
                        Sleep(100);
                        continue;
                    }

                    try {
                        interpretScript(s);
                    }catch (Exception a){
                        telemetry.addLine(a.toString());
                        telemetry.update();
                    }
                    Sleep(100);
                }
            }
        };
        th.start();




        while (opModeIsActive()) {
            TelemetryPacket packet = new TelemetryPacket();
            packet.put("Voltage",getBatteryVoltage());
            dashboard.sendTelemetryPacket(packet);
            //telemetry.addData("Lines:",currentScript.split("\\n").length);
            //telemetry.update();
            if(useRR == 1) {
                /*
                Pose2d poseEstimate = drive.getPoseEstimate();
                telemetry.addData("x", poseEstimate.getX());
                telemetry.addData("y", poseEstimate.getY());
                telemetry.addData("heading", poseEstimate.getHeading());
                telemetry.update();
                 */
            }
            if(!traj && useRR == 1) {
                drive.setWeightedDrivePower(
                        new Pose2d(
                                -gamepad1.left_stick_y * drivePower,
                                -gamepad1.left_stick_x * drivePower,
                                -gamepad1.right_stick_x * drivePower
                        )
                );
            }
        }

        th.interrupt();


    }
}