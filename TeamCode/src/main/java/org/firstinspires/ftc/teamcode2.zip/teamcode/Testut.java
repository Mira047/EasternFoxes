package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

@Autonomous
public class Testut extends LinearOpMode {

    void sleep(int ms){
        try{
            Thread.sleep(ms);
        }catch (InterruptedException e){

        }
    }

    @Override
    public void runOpMode() throws InterruptedException {
        Servo servo = hardwareMap.get(Servo.class, "servo" +
                "0");
        waitForStart();
        while(opModeIsActive()) {
            servo.setPosition(0);
            telemetry.addData("asd",Double.toString(servo.getPosition()));
            telemetry.update();
            sleep(2000);
            servo.setPosition(1);
            telemetry.addData("asd",Double.toString(servo.getPosition()));
            telemetry.update();
            sleep(2000);
        }
    }
}
